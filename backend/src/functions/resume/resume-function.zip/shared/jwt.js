"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateToken = generateToken;
exports.verifyToken = verifyToken;
exports.refreshToken = refreshToken;
const jwt = require("jsonwebtoken");
function generateToken(payload) {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error('JWT_SECRET environment variable is required');
    }
    return jwt.sign(payload, secret, {
        expiresIn: '24h',
        issuer: 'resume-generator'
    });
}
function verifyToken(token) {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        return { success: false, error: 'JWT configuration error' };
    }
    try {
        const payload = jwt.verify(token, secret);
        return { success: true, payload };
    }
    catch (error) {
        if (error.name === 'TokenExpiredError') {
            return { success: false, error: 'Token expired' };
        }
        if (error.name === 'JsonWebTokenError') {
            return { success: false, error: 'Invalid token format' };
        }
        return { success: false, error: 'Token verification failed' };
    }
}
function refreshToken(oldToken) {
    const result = verifyToken(oldToken);
    if (!result.success || !result.payload) {
        return result;
    }
    const newToken = generateToken(result.payload);
    return { success: true, token: newToken, payload: result.payload };
}
