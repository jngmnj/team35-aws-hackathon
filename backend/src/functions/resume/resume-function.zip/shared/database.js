"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TABLE_NAMES = exports.docClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
exports.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
exports.TABLE_NAMES = {
    USERS: process.env.USERS_TABLE_NAME || 'users',
    DOCUMENTS: process.env.DOCUMENTS_TABLE_NAME || 'documents',
    ANALYSIS: process.env.ANALYSIS_TABLE_NAME || 'analysis',
    RESUMES: process.env.RESUMES_TABLE_NAME || 'resumes',
};
