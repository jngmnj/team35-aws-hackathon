"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEmail = validateEmail;
exports.validateDocumentType = validateDocumentType;
exports.validatePassword = validatePassword;
exports.validateRequired = validateRequired;
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
function validateDocumentType(type) {
    const validTypes = [
        'experience', 'skills', 'values', 'achievements',
        'daily_record', 'mood_tracker', 'reflection', 'test_result'
    ];
    return validTypes.includes(type.toLowerCase());
}
function validatePassword(password) {
    return password && password.length >= 6;
}
function validateRequired(value) {
    return value !== null && value !== undefined && value !== '';
}
