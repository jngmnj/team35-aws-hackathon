"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyToken = verifyToken;
const jwt_1 = require("./jwt");
function verifyToken(authHeader) {
    if (!authHeader) {
        return { success: false, error: 'No authorization header' };
    }
    const token = authHeader.replace('Bearer ', '');
    if (!token) {
        return { success: false, error: 'No token provided' };
    }
    const result = (0, jwt_1.verifyToken)(token);
    if (!result.success) {
        return { success: false, error: result.error };
    }
    return {
        success: true,
        userId: result.payload?.userId,
        email: result.payload?.email
    };
}
