"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEmail = validateEmail;
exports.validateDocumentType = validateDocumentType;
exports.validateDocumentData = validateDocumentData;
exports.validatePassword = validatePassword;
exports.validateRequired = validateRequired;
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
function validateDocumentType(type) {
    const validTypes = ['experience', 'skills', 'values', 'achievements', 'daily_record', 'mood_tracker', 'reflection', 'test_result'];
    return validTypes.includes(type.toLowerCase());
}
function validateDocumentData(type, title, content) {
    const errors = [];
    if (!title || title.trim().length === 0) {
        errors.push('Title is required');
    }
    if (title && title.length > 200) {
        errors.push('Title must be less than 200 characters');
    }
    if (content && content.length > 10000) {
        errors.push('Content must be less than 10,000 characters');
    }
    return {
        isValid: errors.length === 0,
        errors,
    };
}
function validatePassword(password) {
    return password && password.length >= 6;
}
function validateRequired(value) {
    return value !== null && value !== undefined && value !== '';
}
