"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const database_1 = require("../../shared/database");
const auth_1 = require("../../shared/auth");
const bedrock_1 = require("../../shared/bedrock");
const utils_1 = require("../../shared/utils");
const handler = async (event) => {
    try {
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
                },
                body: ''
            };
        }
        const authResult = (0, auth_1.verifyToken)(event.headers.Authorization || event.headers.authorization);
        if (!authResult.success) {
            return (0, utils_1.createErrorResponse)(401, 'Unauthorized');
        }
        const userId = authResult.userId;
        const method = event.httpMethod;
        switch (method) {
            case 'GET':
                return await getAnalysis(userId);
            case 'POST':
                let requestBody = {};
                if (event.body) {
                    try {
                        requestBody = JSON.parse(event.body);
                    }
                    catch (error) {
                        return (0, utils_1.createErrorResponse)(400, 'Invalid JSON in request body');
                    }
                }
                return await createAnalysis(userId, requestBody);
            default:
                return (0, utils_1.createErrorResponse)(405, 'Method not allowed');
        }
    }
    catch (error) {
        console.error('Error:', error);
        return (0, utils_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.handler = handler;
async function getAnalysis(userId) {
    const result = await database_1.docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: database_1.TABLE_NAMES.ANALYSIS,
        IndexName: 'userId-index',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
            ':userId': userId,
        },
    }));
    return (0, utils_1.createSuccessResponse)({
        analyses: result.Items || [],
        total: result.Count || 0,
    });
}
async function createAnalysis(userId, body) {
    console.log('Creating analysis for userId:', userId);
    // Get user's documents from database
    const result = await database_1.docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: database_1.TABLE_NAMES.DOCUMENTS,
        IndexName: 'userId-index',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
            ':userId': userId,
        },
    }));
    console.log('Documents query result:', JSON.stringify(result, null, 2));
    const rawDocuments = result.Items || [];
    if (rawDocuments.length === 0) {
        return (0, utils_1.createErrorResponse)(400, 'No documents found for analysis');
    }
    // Map documents to the expected format
    const documents = rawDocuments.map(doc => ({
        type: doc.type || 'Unknown',
        title: doc.title || 'Untitled',
        content: doc.content || ''
    }));
    console.log('Mapped documents for analysis:', documents.length);
    try {
        const analysisResult = await (0, bedrock_1.generatePersonalityAnalysis)({ documents });
        const analysisId = (0, uuid_1.v4)();
        const analysis = {
            analysisId,
            userId,
            result: analysisResult,
            createdAt: new Date().toISOString(),
        };
        await database_1.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: database_1.TABLE_NAMES.ANALYSIS,
            Item: analysis,
        }));
        return (0, utils_1.createSuccessResponse)(analysis, 201);
    }
    catch (error) {
        console.error('AI 분석 실패:', error);
        return (0, utils_1.createErrorResponse)(500, 'AI 분석 서비스 일시 중단. 잠시 후 다시 시도해주세요.');
    }
}
