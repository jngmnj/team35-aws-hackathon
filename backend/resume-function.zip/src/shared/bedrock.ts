import { BedrockRuntimeClient, InvokeModelCommand } from '@aws-sdk/client-bedrock-runtime';

const client = new BedrockRuntimeClient({ 
  region: process.env.BEDROCK_REGION || process.env.AWS_REGION || 'us-east-1'
});

export interface AnalysisPrompt {
  documents: Array<{
    type: string;
    title: string;
    content: string;
  }>;
}

export interface ResumePrompt {
  documents: Array<{
    type: string;
    title: string;
    content: string;
  }>;
  jobCategory: string;
  jobTitle?: string;
}

export interface PersonalityAnalysisResult {
  personalityType: {
    type: string;
    description: string;
    traits: string[];
  };
  strengths: Array<{
    title: string;
    description: string;
    evidence: string;
  }>;
  weaknesses: Array<{
    title: string;
    description: string;
    improvement: string;
  }>;
  values: string[];
  interests: string[];
}

export async function generatePersonalityAnalysis(prompt: AnalysisPrompt): Promise<PersonalityAnalysisResult> {
  const systemPrompt = `당신은 한국 IT 업계를 잘 아는 전문 커리어 컨설턴트입니다. 제공된 문서들을 종합적으로 분석하여 실무 중심의 성격 분석을 해주세요.

📋 문서 분석 방법:
- Experience 문서들: 실제 행동 패턴과 리더십 스타일 파악
- Skills 문서들: 기술 역량과 학습 성향 분석 (여러 개일 수 있음)
- Values 문서들: 업무 가치관과 동기 요인 이해
- Achievements 문서들: 성과 지향성과 강점 확인
- 기타 문서들: 추가 정보로 활용

🎯 분석 기준:
1. 성격 유형: MBTI 기반, 문서에서 나타난 구체적 행동 패턴 근거
2. 핵심 강점: 3-5개 (반드시 문서의 구체적 사례 인용, 실무 적용 방법 포함)
3. 개선 영역: 2-3개 (건설적 피드백과 구체적 개선 방법)
4. 가치관: 문서에서 드러나는 핵심 가치 3-5개
5. 관심 분야: 기술/업무 관심사 3-5개

⚠️ 문서 유형별 처리 방법:
1. 상세 서술형 (50자 이상 + 문장 구조): 구체적 분석 및 근거 인용
2. 키워드 나열형 (쉼표 구분): '○○ 기술에 관심' 수준으로 분석
3. 단답형 (50자 미만): '정보 부족으로 일반적 추정' 명시

예시:
- 팀 프로젝트에서 리더 역할을 한 경우 → 상세 분석
- React, Vue, JavaScript 나열 → 프론트엔드 기술 관심 수준
- 팀워크 단답 → 협업 가치 추정 (근거 부족)

중요 원칙:
- 문서 내용이 부족하면 추측하지 말고 분석 한계 명시
- 반드시 문서에서 직접 인용할 수 있는 내용만 근거로 사용

✅ 강점/약점 작성 가이드:
- ❌ 나쁜 예: 리더십이 뛰어남, 완벽주의 성향
- ✅ 좋은 예: 5명 팀 리더 역할 수행 경험을 통해 보여준 일정 관리와 갈등 조정 능력

한국어로 답변하고, 모든 분석은 제공된 문서 내용을 근거로 해야 합니다.

정확히 이 JSON 구조로만 응답:
{
  "personalityType": {
    "type": "ENFJ",
    "description": "구체적 근거와 함께 성격 설명",
    "traits": ["특성1", "특성2", "특성3"]
  },
  "strengths": [
    {
      "title": "강점명",
      "description": "구체적 사례와 실무 적용 방법",
      "evidence": "문서에서 인용한 근거"
    }
  ],
  "weaknesses": [
    {
      "title": "개선영역명",
      "description": "구체적 상황과 개선 방향",
      "improvement": "실용적 개선 방법"
    }
  ],
  "values": ["가치1", "가치2", "가치3"],
  "interests": ["관심사1", "관심사2", "관심사3"]
}`;

  const userPrompt = `Please analyze the following documents:
${prompt.documents.map(doc => `
Document Type: ${doc.type}
Title: ${doc.title}
Content: ${doc.content}
`).join('\n---\n')}`;

  const body = JSON.stringify({
    anthropic_version: "bedrock-2023-05-31",
    max_tokens: 2000,
    system: systemPrompt,
    messages: [
      {
        role: "user",
        content: userPrompt
      }
    ]
  });

  const command = new InvokeModelCommand({
    modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
    body,
    contentType: "application/json",
    accept: "application/json",
  });

  try {
    const response = await client.send(command);
    const responseBody = JSON.parse(new TextDecoder().decode(response.body));
    const content = responseBody.content[0].text;
    
    try {
      // Remove markdown code blocks if present
      const cleanContent = content.replace(/```json\n?|```\n?/g, '').trim();
      return JSON.parse(cleanContent);
    } catch (parseError) {
      console.error('JSON 파싱 실패:', parseError instanceof Error ? parseError.message : String(parseError));
      console.error('원본 응답:', content);
      return {
        personalityType: { type: "ENFJ", description: "분석 중 오류 발생", traits: ["리더십", "협업", "학습지향"] },
        strengths: [
          { title: "문제해결력", description: "다양한 상황에서 창의적 해결책 제시", evidence: "분석 오류로 인한 기본값" },
          { title: "학습능력", description: "새로운 기술과 지식 습득에 적극적", evidence: "분석 오류로 인한 기본값" },
          { title: "커뮤니케이션", description: "팀원과의 원활한 소통 능력", evidence: "분석 오류로 인한 기본값" }
        ],
        weaknesses: [
          { title: "완벽주의", description: "과도한 완벽 추구로 인한 시간 소요", improvement: "우선순위 설정과 적정 품질 기준 수립" },
          { title: "시간관리", description: "업무 일정 관리의 어려움", improvement: "체계적인 일정 관리 도구 활용" }
        ],
        values: ["팀워크", "성장", "품질"],
        interests: ["개발", "기술", "혁신"]
      };
    }
  } catch (error) {
    console.error('Bedrock 호출 실패:', error);
    throw new Error('AI 분석 서비스 일시 중단');
  }
}

export interface ResumeResult {
  personalInfo: {
    summary: string;
  };
  experience: Array<{
    title: string;
    company: string;
    duration: string;
    description: string;
  }>;
  skills: string[];
  achievements: string[];
}

export async function generateResume(prompt: ResumePrompt): Promise<ResumeResult> {
  const systemPrompt = `You are a resume writer. Create a resume for ${prompt.jobCategory} position.

Analyze the provided documents and create a professional resume.

IMPORTANT: Return ONLY a valid JSON object. No markdown, no code blocks, no explanations. Just pure JSON.

JSON structure:
{
  "personalInfo": {
    "summary": "Professional summary in Korean"
  },
  "experience": [
    {
      "title": "Job title",
      "company": "Company name",
      "duration": "Duration",
      "description": "Job description"
    }
  ],
  "skills": ["skill1", "skill2", "skill3"],
  "achievements": ["achievement1", "achievement2"]
}`;

  const userPrompt = `Target Job Category: ${prompt.jobCategory}
${prompt.jobTitle ? `Specific Job Title: ${prompt.jobTitle}` : ''}

Documents to analyze:
${prompt.documents.map(doc => `
Document Type: ${doc.type}
Title: ${doc.title}
Content: ${doc.content}
`).join('\n---\n')}`;

  const body = JSON.stringify({
    anthropic_version: "bedrock-2023-05-31",
    max_tokens: 3000,
    system: systemPrompt,
    messages: [
      {
        role: "user",
        content: userPrompt
      }
    ]
  });

  const command = new InvokeModelCommand({
    modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
    body,
    contentType: "application/json",
    accept: "application/json",
  });

  let content = '';
  try {
    console.log('Bedrock 호출 시작');
    const response = await client.send(command);
    const responseBody = JSON.parse(new TextDecoder().decode(response.body));
    
    if (!responseBody.content || !responseBody.content[0] || !responseBody.content[0].text) {
      throw new Error('Invalid response format from Bedrock');
    }
    
    content = responseBody.content[0].text;
    console.log('Raw response first 200 chars:', content.substring(0, 200));
    console.log('Content includes backticks:', content.includes('`'));
    console.log('Content includes json marker:', content.toLowerCase().includes('json'));
    
    // Step 1: Remove markdown code blocks and backticks
    let cleanContent = content
      .replace(/```json\s*/gi, '')
      .replace(/```\s*/g, '')
      .replace(/`/g, '')
      .replace(/json\s*/gi, '')
      .trim();
    
    // Step 3: Find JSON object
    const jsonStart = cleanContent.indexOf('{');
    const jsonEnd = cleanContent.lastIndexOf('}');
    
    if (jsonStart === -1 || jsonEnd === -1) {
      console.error('No JSON brackets found in:', cleanContent.substring(0, 200));
      throw new Error('No JSON found');
    }
    
    const jsonStr = cleanContent.substring(jsonStart, jsonEnd + 1);
    console.log('Final JSON string first 100 chars:', jsonStr.substring(0, 100));
    
    const result = JSON.parse(jsonStr);
    console.log('이력서 생성 성공');
    return result;
  } catch (parseError) {
    console.error('JSON 파싱 실패:', parseError instanceof Error ? parseError.message : String(parseError));
    console.error('원본 응답 전체:', content);
    
    // Try alternative parsing methods
    try {
      // Method 1: Remove everything before first { and after last }
      const start = content.indexOf('{');
      const end = content.lastIndexOf('}') + 1;
      if (start !== -1 && end > start) {
        const extracted = content.slice(start, end);
        return JSON.parse(extracted);
      }
    } catch (e) {
      console.error('Alternative parsing failed:', e instanceof Error ? e.message : String(e));
    }
    
    // Return safe fallback
    return {
      personalInfo: { summary: `${prompt.jobCategory} 분야의 전문성을 갖춘 개발자입니다.` },
      experience: [{
        title: "개발자",
        company: "프로젝트",
        duration: "진행중",
        description: "다양한 기술을 활용한 개발 경험"
      }],
      skills: ["JavaScript", "React", "문제해결력"],
      achievements: ["프로젝트 성공적 완료", "팀워크 발휘"]
    };
  }
} 