"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getHeaders = getHeaders;
exports.createResponse = createResponse;
exports.createErrorResponse = createErrorResponse;
exports.createSuccessResponse = createSuccessResponse;
function getHeaders() {
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };
}
function createResponse(statusCode, data) {
    return {
        statusCode,
        headers: getHeaders(),
        body: JSON.stringify(data),
    };
}
function createErrorResponse(statusCode, message) {
    return createResponse(statusCode, {
        success: false,
        error: { message },
    });
}
function createSuccessResponse(data, statusCode = 200) {
    return createResponse(statusCode, {
        success: true,
        data,
    });
}
