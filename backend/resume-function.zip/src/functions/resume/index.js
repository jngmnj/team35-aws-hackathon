"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const database_1 = require("./shared/database");
const auth_1 = require("./shared/auth");
const bedrock_1 = require("./shared/bedrock");
const utils_1 = require("./shared/utils");
const handler = async (event) => {
    try {
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                },
                body: ''
            };
        }
        const authResult = (0, auth_1.verifyToken)(event.headers.Authorization || event.headers.authorization);
        if (!authResult.success) {
            return (0, utils_1.createErrorResponse)(401, 'Unauthorized');
        }
        const userId = authResult.userId;
        const method = event.httpMethod;
        switch (method) {
            case 'GET':
                return await getResumes(userId, event.queryStringParameters);
            case 'POST':
                let requestBody = {};
                if (event.body) {
                    try {
                        requestBody = JSON.parse(event.body);
                    }
                    catch (error) {
                        return (0, utils_1.createErrorResponse)(400, 'Invalid JSON in request body');
                    }
                }
                return await createResume(userId, requestBody);
            default:
                return (0, utils_1.createErrorResponse)(405, 'Method not allowed');
        }
    }
    catch (error) {
        console.error('Error:', error);
        return (0, utils_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.handler = handler;
async function getResumes(userId, queryParams) {
    // Validate userId to prevent injection
    if (!userId || typeof userId !== 'string' || userId.length === 0) {
        return (0, utils_1.createErrorResponse)(400, 'Invalid user ID');
    }
    const jobCategory = queryParams?.jobCategory;
    // Validate jobCategory if provided
    if (jobCategory && (typeof jobCategory !== 'string' || jobCategory.length === 0)) {
        return (0, utils_1.createErrorResponse)(400, 'Invalid job category');
    }
    let queryCommand;
    if (jobCategory) {
        queryCommand = new lib_dynamodb_1.QueryCommand({
            TableName: database_1.TABLE_NAMES.RESUMES,
            IndexName: 'userId-jobCategory-index',
            KeyConditionExpression: 'userId = :userId AND jobCategory = :jobCategory',
            ExpressionAttributeValues: {
                ':userId': userId,
                ':jobCategory': jobCategory,
            },
        });
    }
    else {
        queryCommand = new lib_dynamodb_1.QueryCommand({
            TableName: database_1.TABLE_NAMES.RESUMES,
            IndexName: 'userId-jobCategory-index',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': userId,
            },
        });
    }
    try {
        const result = await database_1.docClient.send(queryCommand);
        return (0, utils_1.createSuccessResponse)({
            resumes: result.Items || [],
            total: result.Count || 0,
        });
    }
    catch (error) {
        console.error('DynamoDB query error:', error);
        return (0, utils_1.createErrorResponse)(500, 'Failed to retrieve resumes');
    }
}
async function createResume(userId, body) {
    // Validate userId to prevent injection
    if (!userId || typeof userId !== 'string' || userId.length === 0) {
        return (0, utils_1.createErrorResponse)(400, 'Invalid user ID');
    }
    const { jobCategory, jobTitle } = body;
    if (!jobCategory || typeof jobCategory !== 'string' || jobCategory.length === 0) {
        return (0, utils_1.createErrorResponse)(400, 'Valid job category is required');
    }
    // Get user's documents from database
    const result = await database_1.docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: database_1.TABLE_NAMES.DOCUMENTS,
        IndexName: 'userId-index',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
            ':userId': userId,
        },
    }));
    const documents = (result.Items || []);
    if (documents.length === 0) {
        return (0, utils_1.createErrorResponse)(400, 'No documents found for resume generation');
    }
    try {
        const resumeResult = await (0, bedrock_1.generateResume)({ documents, jobCategory, jobTitle });
        const resumeId = (0, uuid_1.v4)();
        const resume = {
            resumeId,
            userId,
            jobCategory,
            jobTitle,
            content: resumeResult,
            createdAt: new Date().toISOString(),
        };
        await database_1.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: database_1.TABLE_NAMES.RESUMES,
            Item: resume,
        }));
        return (0, utils_1.createSuccessResponse)(resume, 201);
    }
    catch (error) {
        console.error('이력서 생성 실패:', error);
        return (0, utils_1.createErrorResponse)(500, '이력서 생성 서비스 일시 중단. 잠시 후 다시 시도해주세요.');
    }
}
