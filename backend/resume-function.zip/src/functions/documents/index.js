"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const auth_1 = require("./shared/auth");
const validation_1 = require("./shared/validation");
const error_handler_1 = require("./shared/error-handler");
const utils_1 = require("./shared/utils");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, If-Match',
};
const handler = async (event) => {
    try {
        if (event.httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers, body: '' };
        }
        // Verify JWT token using shared utility
        const authResult = (0, auth_1.verifyToken)(event.headers.Authorization || event.headers.authorization);
        if (!authResult.success) {
            return (0, utils_1.createErrorResponse)(401, 'Unauthorized');
        }
        const userId = authResult.userId;
        const method = event.httpMethod;
        const pathParameters = event.pathParameters;
        let requestBody = {};
        if (event.body && ['POST', 'PUT', 'PATCH'].includes(method)) {
            try {
                requestBody = JSON.parse(event.body);
            }
            catch (error) {
                return (0, utils_1.createErrorResponse)(400, 'Invalid JSON in request body');
            }
        }
        switch (method) {
            case 'GET':
                if (pathParameters?.id) {
                    return await getDocument(pathParameters.id, userId);
                }
                return await getDocuments(userId, event.queryStringParameters);
            case 'POST':
                return await createDocument(userId, requestBody);
            case 'PUT':
                if (!pathParameters?.id) {
                    return (0, utils_1.createErrorResponse)(400, 'Document ID is required');
                }
                return await updateDocument(pathParameters.id, requestBody, userId);
            case 'PATCH':
                if (!pathParameters?.id) {
                    return (0, utils_1.createErrorResponse)(400, 'Document ID is required');
                }
                return await patchDocument(pathParameters.id, requestBody, userId);
            case 'DELETE':
                if (!pathParameters?.id) {
                    return (0, utils_1.createErrorResponse)(400, 'Document ID is required');
                }
                return await deleteDocument(pathParameters.id, userId);
            default:
                return (0, utils_1.createErrorResponse)(405, 'Method not allowed');
        }
    }
    catch (error) {
        console.error('Error:', error);
        // Handle DynamoDB specific errors
        if (error.name && error.name.includes('Exception')) {
            const dbError = (0, error_handler_1.handleDynamoDBError)(error);
            return {
                statusCode: dbError.statusCode,
                headers,
                body: JSON.stringify({ success: false, error: dbError.error }),
            };
        }
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Internal server error' } }),
        };
    }
};
exports.handler = handler;
async function getDocument(documentId, userId) {
    const document = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: process.env.DOCUMENTS_TABLE_NAME,
        Key: { documentId },
    }));
    if (!document.Item) {
        return (0, utils_1.createErrorResponse)(404, 'Document not found');
    }
    if (document.Item.userId !== userId) {
        return (0, utils_1.createErrorResponse)(403, 'Access denied');
    }
    return (0, utils_1.createSuccessResponse)(document.Item);
}
async function getDocuments(userId, queryParams) {
    // Validate userId to prevent injection
    if (!userId || typeof userId !== 'string' || userId.length === 0) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Invalid user ID' } }),
        };
    }
    let keyConditionExpression = 'userId = :userId';
    const expressionAttributeValues = {
        ':userId': userId,
    };
    // Add type filter if provided and validated
    if (queryParams?.type && (0, validation_1.validateDocumentType)(queryParams.type)) {
        keyConditionExpression += ' AND #type = :type';
        expressionAttributeValues[':type'] = queryParams.type;
    }
    try {
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: process.env.DOCUMENTS_TABLE_NAME,
            IndexName: 'userId-index',
            KeyConditionExpression: keyConditionExpression,
            ExpressionAttributeNames: queryParams?.type ? { '#type': 'type' } : undefined,
            ExpressionAttributeValues: expressionAttributeValues,
        }));
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                data: {
                    documents: result.Items || [],
                    total: result.Count || 0,
                    hasMore: false // TODO: Implement pagination logic
                },
                timestamp: new Date().toISOString()
            }),
        };
    }
    catch (error) {
        console.error('DynamoDB query error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Database query failed' } }),
        };
    }
}
async function createDocument(userId, body) {
    // Validate userId to prevent injection
    if (!userId || typeof userId !== 'string' || userId.length === 0) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Invalid user ID' } }),
        };
    }
    const { type, title, content } = body;
    if (!type || !title) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Missing required fields' } }),
        };
    }
    if (!(0, validation_1.validateDocumentType)(type)) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Invalid document type' } }),
        };
    }
    const validation = (0, validation_1.validateDocumentData)(type, title, content);
    if (!validation.isValid) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Validation failed', details: validation.errors } }),
        };
    }
    const documentId = (0, uuid_1.v4)();
    const now = new Date().toISOString();
    const document = {
        documentId,
        userId,
        type,
        title,
        content: content || '',
        version: 1,
        createdAt: now,
        updatedAt: now,
    };
    try {
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: process.env.DOCUMENTS_TABLE_NAME,
            Item: document,
        }));
        return {
            statusCode: 201,
            headers,
            body: JSON.stringify({
                success: true,
                data: document,
            }),
        };
    }
    catch (error) {
        console.error('DynamoDB put error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Failed to create document' } }),
        };
    }
}
async function updateDocument(documentId, body, userId) {
    const { title, content, type } = body;
    if (!documentId) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Document ID is required' } }),
        };
    }
    // Check document ownership
    const ownershipCheck = await verifyDocumentOwnership(documentId, userId);
    if (!ownershipCheck.success) {
        return ownershipCheck.response;
    }
    if (!title && !content) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'No fields to update' } }),
        };
    }
    // If type is provided, validate the document data
    if (type && title) {
        if (!(0, validation_1.validateDocumentType)(type)) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ success: false, error: { message: 'Invalid document type' } }),
            };
        }
        const validation = (0, validation_1.validateDocumentData)(type, title, content);
        if (!validation.isValid) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ success: false, error: { message: 'Validation failed', details: validation.errors } }),
            };
        }
    }
    const updateExpression = [];
    const expressionAttributeValues = {};
    if (title) {
        updateExpression.push('title = :title');
        expressionAttributeValues[':title'] = title;
    }
    if (content) {
        updateExpression.push('content = :content');
        expressionAttributeValues[':content'] = content;
    }
    updateExpression.push('updatedAt = :updatedAt', '#version = #version + :inc');
    expressionAttributeValues[':updatedAt'] = new Date().toISOString();
    expressionAttributeValues[':inc'] = 1;
    const result = await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: process.env.DOCUMENTS_TABLE_NAME,
        Key: { documentId },
        UpdateExpression: `SET ${updateExpression.join(', ')}`,
        ExpressionAttributeNames: { '#version': 'version' },
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: 'ALL_NEW',
    }));
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            data: result.Attributes,
        }),
    };
}
async function patchDocument(documentId, body, userId) {
    const { title, content, version: clientVersion } = body;
    if (!title && !content) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'No fields to update' } }),
        };
    }
    // Check document ownership
    const ownershipCheck = await verifyDocumentOwnership(documentId, userId);
    if (!ownershipCheck.success) {
        return ownershipCheck.response;
    }
    // Get current document for version check
    const currentDoc = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: process.env.DOCUMENTS_TABLE_NAME,
        Key: { documentId },
    }));
    if (!currentDoc.Item) {
        return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Document not found' } }),
        };
    }
    // Version conflict check for concurrent editing
    if (clientVersion && currentDoc.Item.version !== clientVersion) {
        return {
            statusCode: 409,
            headers,
            body: JSON.stringify({
                success: false,
                error: {
                    message: 'Document has been modified by another user',
                    currentVersion: currentDoc.Item.version,
                    conflictData: currentDoc.Item
                }
            }),
        };
    }
    const updateExpression = [];
    const expressionAttributeValues = {};
    if (title !== undefined) {
        updateExpression.push('title = :title');
        expressionAttributeValues[':title'] = title;
    }
    if (content !== undefined) {
        updateExpression.push('content = :content');
        expressionAttributeValues[':content'] = content;
    }
    updateExpression.push('updatedAt = :updatedAt', '#version = #version + :inc');
    expressionAttributeValues[':updatedAt'] = new Date().toISOString();
    expressionAttributeValues[':inc'] = 1;
    const result = await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: process.env.DOCUMENTS_TABLE_NAME,
        Key: { documentId },
        UpdateExpression: `SET ${updateExpression.join(', ')}`,
        ExpressionAttributeNames: { '#version': 'version' },
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: 'ALL_NEW',
    }));
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            data: result.Attributes,
        }),
    };
}
async function deleteDocument(documentId, userId) {
    if (!documentId) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: { message: 'Document ID is required' } }),
        };
    }
    // Check document ownership
    const ownershipCheck = await verifyDocumentOwnership(documentId, userId);
    if (!ownershipCheck.success) {
        return ownershipCheck.response;
    }
    await docClient.send(new lib_dynamodb_1.DeleteCommand({
        TableName: process.env.DOCUMENTS_TABLE_NAME,
        Key: { documentId },
    }));
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            message: 'Document deleted successfully',
        }),
    };
}
async function verifyDocumentOwnership(documentId, userId) {
    const document = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: process.env.DOCUMENTS_TABLE_NAME,
        Key: { documentId },
    }));
    if (!document.Item) {
        return {
            success: false,
            response: {
                statusCode: 404,
                headers,
                body: JSON.stringify({ success: false, error: { message: 'Document not found' } }),
            }
        };
    }
    if (document.Item.userId !== userId) {
        return {
            success: false,
            response: {
                statusCode: 403,
                headers,
                body: JSON.stringify({ success: false, error: { message: 'Access denied: You can only modify your own documents' } }),
            }
        };
    }
    return { success: true, document: document.Item };
}
