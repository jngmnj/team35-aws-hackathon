"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const bcrypt = __importStar(require("bcryptjs"));
const jwt_1 = require("./shared/jwt");
const database_1 = require("./shared/database");
const utils_1 = require("./shared/utils");
const validation_1 = require("./shared/validation");
const error_handler_1 = require("./shared/error-handler");
const handler = async (event) => {
    try {
        const path = event.path;
        const method = event.httpMethod;
        if (method === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                },
                body: ''
            };
        }
        let body = {};
        if (event.body) {
            try {
                body = JSON.parse(event.body);
            }
            catch (error) {
                return (0, utils_1.createErrorResponse)(400, 'Invalid JSON in request body');
            }
        }
        if (path.endsWith('/register')) {
            return await handleRegister(body);
        }
        else if (path.endsWith('/login')) {
            return await handleLogin(body);
        }
        return (0, utils_1.createErrorResponse)(404, 'Not found');
    }
    catch (error) {
        console.error('Error:', error);
        // Handle DynamoDB specific errors
        if (error.name && error.name.includes('Exception')) {
            const dbError = (0, error_handler_1.handleDynamoDBError)(error);
            return {
                statusCode: dbError.statusCode,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ success: false, error: dbError.error }),
            };
        }
        return (0, utils_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.handler = handler;
async function handleRegister(body) {
    const { email, password, name } = body;
    if (!email || !password || !name) {
        return (0, utils_1.createErrorResponse)(400, 'Missing required fields');
    }
    if (!(0, validation_1.validateEmail)(email)) {
        return (0, utils_1.createErrorResponse)(400, 'Invalid email format');
    }
    if (password.length < 6) {
        return (0, utils_1.createErrorResponse)(400, 'Password must be at least 6 characters');
    }
    const existingUser = await database_1.docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: database_1.TABLE_NAMES.USERS,
        Key: { userId: email },
    }));
    if (existingUser.Item) {
        return (0, utils_1.createErrorResponse)(400, 'User already exists');
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = email; // Use email as userId for consistency
    await database_1.docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: database_1.TABLE_NAMES.USERS,
        Item: {
            userId,
            email,
            name,
            password: hashedPassword,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        },
    }));
    const token = (0, jwt_1.generateToken)({ userId, email });
    return (0, utils_1.createSuccessResponse)({ userId, email, name, token }, 201);
}
async function handleLogin(body) {
    const { email, password } = body;
    if (!email || !password) {
        return (0, utils_1.createErrorResponse)(400, 'Email and password are required');
    }
    if (!(0, validation_1.validateEmail)(email)) {
        return (0, utils_1.createErrorResponse)(400, 'Invalid email format');
    }
    const result = await database_1.docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: database_1.TABLE_NAMES.USERS,
        Key: { userId: email },
    }));
    if (!result.Item) {
        return (0, utils_1.createErrorResponse)(401, 'Invalid credentials');
    }
    const isValid = await bcrypt.compare(password, result.Item.password);
    if (!isValid) {
        return (0, utils_1.createErrorResponse)(401, 'Invalid credentials');
    }
    const token = (0, jwt_1.generateToken)({
        userId: result.Item.userId,
        email: result.Item.email
    });
    return (0, utils_1.createSuccessResponse)({
        userId: result.Item.userId,
        email: result.Item.email,
        name: result.Item.name,
        token,
    });
}
