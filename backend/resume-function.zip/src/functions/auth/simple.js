exports.handler = async (event) => {
  console.log('Simple function called');
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Mock response for testing
  if (event.path.endsWith('/register') || event.path.endsWith('/login')) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        data: {
          userId: 'test-user-123',
          email: 'test@example.com',
          name: 'Test User',
          token: 'mock-jwt-token-for-testing'
        }
      }),
    };
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      message: 'Simple function working!',
      method: event.httpMethod,
      path: event.path
    }),
  };
};