const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

exports.handler = async (event) => {
  try {
    if (event.httpMethod === 'OPTIONS') {
      return { statusCode: 200, headers, body: '' };
    }

    const path = event.path;
    const body = JSON.parse(event.body || '{}');

    if (path.endsWith('/register')) {
      return await handleRegister(body);
    } else if (path.endsWith('/login')) {
      return await handleLogin(body);
    }

    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ success: false, error: { message: 'Not found' } }),
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: { message: 'Internal server error' } }),
    };
  }
};

async function handleRegister(body) {
  const { email, password, name } = body;

  if (!email || !password || !name) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: { message: 'Missing required fields' } }),
    };
  }

  const existingUser = await docClient.send(new GetCommand({
    TableName: process.env.USERS_TABLE_NAME,
    Key: { userId: email },
  }));

  if (existingUser.Item) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: { message: 'User already exists' } }),
    };
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const userId = uuidv4();

  await docClient.send(new PutCommand({
    TableName: process.env.USERS_TABLE_NAME,
    Item: {
      userId: email,  // Use email as primary key
      email,
      name,
      password: hashedPassword,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  }));

  const token = jwt.sign({ userId: email, email }, process.env.JWT_SECRET, { expiresIn: '24h' });

  return {
    statusCode: 201,
    headers,
    body: JSON.stringify({
      success: true,
      data: { userId, email, name, token },
    }),
  };
}

async function handleLogin(body) {
  const { email, password } = body;

  const result = await docClient.send(new GetCommand({
    TableName: process.env.USERS_TABLE_NAME,
    Key: { userId: email },
  }));

  if (!result.Item) {
    return {
      statusCode: 401,
      headers,
      body: JSON.stringify({ success: false, error: { message: 'Invalid credentials' } }),
    };
  }

  const isValid = await bcrypt.compare(password, result.Item.password);
  if (!isValid) {
    return {
      statusCode: 401,
      headers,
      body: JSON.stringify({ success: false, error: { message: 'Invalid credentials' } }),
    };
  }

  const token = jwt.sign(
    { userId: result.Item.userId, email: result.Item.email },
    process.env.JWT_SECRET,
    { expiresIn: '24h' }
  );

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      data: {
        userId: result.Item.userId,
        email: result.Item.email,
        name: result.Item.name,
        token,
      },
    }),
  };
}